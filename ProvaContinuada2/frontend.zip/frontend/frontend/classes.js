class Aluno{

	constructor(nome, nota){
		this.nome = nome;
		this.nota = nota;
	}

	lerNota(){
		return this.nota;
	}
}

class Faculdade{

	constructor(alunos){
		this.alunos = alunos;
	}

	lerMediaDosAlunos(){
		var somaDasMediasDosAlunos = 0;
		for(var i = 0; i < alunos.length; i++){
			somaDasMediasDosAlunos += alunos[i].lerNota();
		}
	
		var media = somaDasMediasDosAlunos / alunos.length;
		return media;
	}
}

antonioDosSantos = new Aluno("Antonio dos Santos", 5);
carlosDaSilva = new Aluno("Carlos da Silva", 8);
claudiaFernandes = new Aluno("Claudia Fernandes", 7);
fernandaAlmeida = new Aluno("Fernanda Almeida", 4);

alunos = [antonioDosSantos, carlosDaSilva, claudiaFernandes, fernandaAlmeida];

faculdade = new Faculdade(alunos);
console.log("Media dos alunos "+ faculdade.lerMediaDosAlunos());
console.log("A media esta correta? Deveria ser 6! " + (faculdade.lerMediaDosAlunos() == 6))
