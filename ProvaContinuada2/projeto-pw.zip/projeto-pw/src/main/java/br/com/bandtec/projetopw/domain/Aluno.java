package br.com.bandtec.projetopw.domain;

import java.util.UUID;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="alunos")
public class Aluno {
	
	@Id @GeneratedValue
	private UUID id;
	private String nome;
	@Embedded
	private RA ra;
	
	@Enumerated(EnumType.STRING)
	private Semestre semestre;
	
	protected Aluno() {}
	
	public Aluno(String nome, RA ra) {
		this.nome = nome;
		this.ra = ra;
		this.semestre = Semestre.PRIMEIRO;
	}

	public void passarDeSemestre() {
		this.semestre = Semestre.lerProximo(this.semestre);
	}

	public Semestre lerSemestreAtual() {
		return semestre;
	}

	public UUID getId() {
		return id;
	}
}
